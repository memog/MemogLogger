//
//  MemogLogger.h
//  MemogLogger
//
//  Created by Guillermo García on 15/01/19.
//  Copyright © 2019 Inmediatum. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MemogLogger.
FOUNDATION_EXPORT double MemogLoggerVersionNumber;

//! Project version string for MemogLogger.
FOUNDATION_EXPORT const unsigned char MemogLoggerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MemogLogger/PublicHeader.h>


